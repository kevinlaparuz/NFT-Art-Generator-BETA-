# NFT Generator & NFT Creator by Kevin Laparuz

Python version of the popular C# program from the developer Discord server at https://discord.gg/qfvTFVz - join our Discord today!

Python program focused on creating generative NFT collections based on layers of art. 
[BETA - design & functionality might vary!]


## Project Goals

Making a platform-agnostic generative art program for programmers and non-programmers alike. 
Includes an extra focus for Fantom marketplaces e.g. PaintSwap. The source is written in **Python** to make it easier and more accessible to contribute to.


## Dependencies
* PyYAML
* Pillow (PIL Fork)
* Additional Modules | install-modules.bat
* All other dependencies come built-in with Python.

## How to use

Step 1. Download the .zip source code.

Step 2. Run "install-modules.bat" to install required Python dependencies

Step 3. Configure settings in config.yaml.

Step 4. Organise Layers in the art-engine directory.

### Organise Layers

Inside the `art-engine` directory, create a new folder called assets. Inside of should be
all of your organised folders of layers to be used to create your images. It should look
something like this:

    └── assets/
    
        ├── Body/
        
        │   ├── Alien
        │   ├── Human
        │   ├── Robot
        │   └── Monster
        
        ├── Beard/
        
        │   ├── Long Beard
        │   ├── Short Beard
        │   ├── Cool Beard
        │   └── Pink Beard
        
        └── Eye Accessory/
            ├── Sunglasses
            ├── Eyepatch
            └── Visor

In the `config.yaml` file add your layer folder names, exactly as they appear in your assets folder. Place them in the order you wish to appear, e.g. Background, then Body, then Eye, Accessory etc.

### Setting Rarities

The values in the rarities represent how often you want each layer to occur as a percentage out of 100.

For example, if you have two backgrounds, you may set the rarities to `[80, 20]`. 

The rarities should be in the same order as the layers are in the folder (typically alphabetical).

If the layer is *not* mandatory - e.g. a hat/accessory - add an extra value into rarities to represent the None value.

For example, if you have two hats, you could set the rarities as `[60, 30, 10]`. This means the first hat will occur 60% of the time, the second 30% of the time, and *no accessory* 10% of the time.

### Running The Program

Inside of the `NFT-Generator-by-Kevin-Laparuz` folder, open a terminal and run `python art-engine` and your
images and metadata will start being created
